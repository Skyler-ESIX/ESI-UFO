# UFO
Drive an UFO in FiveM.

<img src=https://imgur.com/IZ3IL5o.png>

## Installation
* Download the resource ;
* Drag and drop it in your resources folder ;
* Add ```start ufo``` to you ```server.cfg```.

## Usage
* Type ```/ufo``` when in-game.
* Use G to toggle the wheels and E to toggle stationary mode.

## Updates
No updates yet.

## Notes
* There could be entity networking problems making the ufo invisible for other players.
* As the camera is handled by the script when you are in the vehicle you willnot be able to turn it as you normally do.
* Have Fun 

Made by Skerix#1517